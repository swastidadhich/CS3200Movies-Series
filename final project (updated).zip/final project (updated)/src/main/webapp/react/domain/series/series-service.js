const SERIES_URL = "http://localhost:8080/api/series"

export const createSeries = (series) =>
    fetch(SERIES_URL, {
        method: 'POST',
        body: JSON.stringify(course),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export const findAllSeries = () =>
    fetch(COURSE_URL)
        .then(response => response.json())

export const findSeriesById = (id) =>
    fetch(`${COURSE_URL}/${id}`)
        .then(response => response.json())

export const updateSeries = (id, course) =>
    fetch(`${COURSE_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(course),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

const deleteSeries = (id) =>
    fetch(`${COURSE_URL}/${id}`, {
        method: "DELETE"
    })

export default {
    createSeries,
    findAllSeries,
    findSeriesById,
    updateSeries,
    deleteSeries
}