import MovieEditorInline from "./movie-editor-inline";
import movieService, {createMovieForSeries} from "./movie-service"

const SERIES_URL = "http://localhost:8080/api/series"
const { useState, useEffect } = React;
const {Link, useParams, useHistory} = window.ReactRouterDOM;

const MovieList = () => {
    const [movies, setMovies] = useState([])
    const [newMovie, setNewMovie] = useState({})
    const {seriesId} = useParams()
    useEffect(() => {
        findMoviesForSeries(seriesId)
    }, [])
    const createMovieForSeries = (movie) =>
        movieService.createMovieForSeries(seriesId, movie)
            .then(movie => {
                setNewMovie({title:''})
                setMovies(movies => ([...movies, movie]))
            })
    const updateMovie = (id, newMovie) =>
        movieService.updateMovie(id, newMovie)
            .then(movie => setMovies(movies => (movies.map(movie => movie.id === id ? newMovie : movie))))
    const findMoviesForSeries = (seriesId) =>
        movieService.findMoviesForSeries(seriesId)
            .then(movies => setMovies(movies))
    const deleteMovie = (id) =>
        movieService.deleteMovie(id)
            .then(movies => setMovies(movies => movies.filter(movie => movie.id !== id)))
    return(
        <div>
            <h2>
                <Link onClick={() => history.back()}>
                    <i className="fas fa-arrow-left margin-right-10px"></i>
                </Link>
                Movies
            </h2>
            <ul className="list-group">
                <li className="list-group-item">
                    <div className="row">
                        <div className="col">
                            <input placeholder="Movie Title"
                                   title="Please enter a title for the movie"
                                   className="form-control"
                                   value={newMovie.title}
                                   onChange={(e) => setNewMovie(newMovie => ({...newMovie, title: e.target.value}))}/>
                        </div>
                        <div className="col-2">
                            <i className="fas float-right fa-plus fa-2x" onClick={() => createMovieForSeries(newMovie)}></i>
                        </div>
                    </div>
                </li>
            {
                movies.map(movie =>
                    <li key={movie.id} className="list-group-item">
                        <MovieEditorInline key={movie._id}
                                           updateMovie={updateMovie}
                                           deleteMovie={deleteMovie}
                                           movie={movie}/>
                    </li>)
            }
            </ul>
        </div>
    )
}

export default MovieList;