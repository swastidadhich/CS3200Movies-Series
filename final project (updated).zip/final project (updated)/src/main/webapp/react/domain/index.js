import SeriesList from "./series/series-list";
import MovieList from "./movies/movie-list";
import SeriesEditorForm from "./series/series-editor-form";
import MovieEditorForm from "./movies/movie-editor-form";

const {HashRouter, Link, Route} = window.ReactRouterDOM;
 
const App = () => {
    console.log(window.ReactRouterDOM)
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/series", "/"]} exact={true}>
                    <SeriesList/>
                </Route>
                <Route path="/series/:id" exact={true}>
                    <SeriesEditorForm/>
                </Route>
                <Route path="/series/:seriesId/movies" exact={true}>
                    <SeriesList/>
                </Route>
                <Route path="/movies/:movieId" exact={true}>
                    <MovieEditorForm/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
